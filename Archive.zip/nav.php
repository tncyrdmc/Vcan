<div class="nav-bg">
		<div class="logo">

		</div>

		<div>
			<nav class="nav">
				<ul>
					<li><a href="services.php">SERVICES</a></li>
					<li><a href="instant-quote.php">GET QUOTE</a></li>
				</ul>
			</nav>
        </div>
        <div class="menu-btt">
        	<a href="#" id="open-bt"><i class="material-icons" style="font-size:36px;color: white">menu</i></a>
        </div>
</div>
<div class="full-bg-menu">
    <ul>
    	<a href="#" id="close-bt"><i class="material-icons" style="font-size:36px">close</i></a>
        <li><a href="index.php">HOME</a></li>
		<li><a href="about.php">ABOUT US</a></li>
		<li><a href="contact.php">CONTACT US</a></li>
     </ul>

      <div class="social-m">
    	<ul>
    		<li><a href="http://"><i class="fa fa-facebook-official" style="font-size:24px"></i></a></li>
    		<li><a href="http://"><i class="fa fa-twitter" style="font-size:24px"></i></a></li>
    		<li><a href="http://"><i class="fa fa-google" style="font-size:24px"></i></a></li>
    		<li><a href="http://"><i class="fa fa-instagram" style="font-size:24px"></i></a></li>
    	</ul>
    </div>
</div>