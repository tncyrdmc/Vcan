<footer>
		<div class="ft-container">
			<div class="ft-text-contain">
			    <div class="ft-row-container">
			    	<div class="ft-row">
			    	    <ul id="ft-ul">
			    	    	<li><a href="#home">HOME</a></li>
			    	    	<li><a href="about.php">ABOUT US</a></li>
			    	    	<li><a href="http://">HOW WE HELP</a></li>
			    	    </ul>
			    	</div>
			    	<div class="ft-row">
					    <ul id="com">
						    <li><i class="material-icons" style="font-size:34px;color:pink">phone</i>+919705565777</li>
			    	    	<li><i class="material-icons" style="font-size:34px;color:pink">email</i>hello@efelle.com</li>
			    	    	<li><i class="material-icons" style="font-size:34px;color:pink">location_on</i>Fci colony, vigneswar nagar,<br>valasapakala. Kakinada - 533005 E.G.DT Andhrapradesh</li>
			    	    </ul>
                    </div>
			    </div>

			    <div class="social-m">
			    	<ul>
			    		<li><a href="http://"><i class="fa fa-facebook-official" style="font-size:24px"></i></a></li>
			    		<li><a href="http://"><i class="fa fa-twitter" style="font-size:24px"></i></a></li>
			    		<li><a href="http://"><i class="fa fa-google" style="font-size:24px"></i></a></li>
			    		<li><a href="http://"><i class="fa fa-instagram" style="font-size:24px"></i></a></li>
			    	</ul>
			    </div>
    
			    <div class="cp-right">
			    	<p>2005-2018 vcan, inc. All rights reserved - Privacy Policy </p>
			    </div>
			</div>
		</div>
</footer>


	<!--chat form-->
	<div id="chat-container" class="chat-container">
		<span><a href="" id="chat-bt">support</a></span>
		<div class="chat-form" >
		    <form action="" id="chat-form">
		    	<div>
		    		<input type="text" name="name" placeholder="Name" id="">				
				</div>
				<div>
		    		<input type="mail" name="mail" placeholder="Mail" id="">				
		    	</div>
		    	<div>
		    		<textarea name="message" id="" cols="30" rows="10" placeholder="Message" ></textarea>			
		    	</div>
		    	<div>
		    		<input type="submit" name="submit" id="" value="Sent">				
		    	</div>
		    </form>
		    </div>
	</div>


	<!---->
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/animate.js"></script>
